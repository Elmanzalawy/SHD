<?php if(isset($department)): ?>
<div class="card select-subject card-<?php echo e($department); ?>">
  <?php else: ?>
  <div class="card card-general">
  <?php endif; ?>
    <div class="card-header" id="">
      <h2 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($subjectTrimmed = str_replace(" ","_",$subject)); ?>" aria-expanded="false" aria-controls="collapseOne">
          <?php echo e($subject); ?>  
        </button>
      </h2>
    </div>
  
    <div id="collapse-<?php echo e($subjectTrimmed); ?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body" style="background:#333 !important;">
        <?php $__currentLoopData = $ExamArchive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($exam->subject==$subject): ?>
          <h5><a target="_blank" href="../../storage/app/public/exam_archive/<?php echo e($exam->filename); ?>"><?php echo e($exam->type); ?> <?php echo e($exam->year); ?></a>
          
          <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->privilege == "admin"): ?>
                
            
              <?php echo Form::open(['action'=>['ExamsController@destroy', $exam->id], 'method'=>'POST', 'class'=>'pull-right']); ?>

                  
                  <?php echo e(Form::hidden('_method','DELETE')); ?>

                  <?php echo e(Form::submit('Delete',['class'=>'btn btn-sm pull-right btn-danger'])); ?>

              <?php echo Form::close(); ?>

            <?php endif; ?>
          <?php endif; ?>
          </h5>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/includes/exam_card.blade.php ENDPATH**/ ?>