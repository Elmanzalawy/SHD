<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>
;
<div class="container">
<h1 style="margin-top:2rem !important;" class="center">UPCOMING EVENTS</h1>
<a class="btn btn-lg btn-primary">Create New Event</a>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam magnam doloribus repellendus velit iste, tempora et facilis repellat laborum distinctio facere nulla minima architecto. Blanditiis, earum mollitia. Aspernatur neque velit suscipit tempore! Corporis distinctio impedit praesentium voluptatibus doloribus ea molestias pariatur? Vitae tempore ducimus culpa inventore accusantium quia optio consequatur!</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.event_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/pages/events.blade.php ENDPATH**/ ?>