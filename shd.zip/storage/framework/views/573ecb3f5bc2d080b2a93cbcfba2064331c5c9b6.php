<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>
<div class="container">
    <div class="jumbotron">
    
    <h1 class="center"><?php echo e($event->title); ?></h1>
    <img class="py-2" style="width:100%;" src="../../storage/app/public/event_images/<?php echo e($event->cover_image); ?>" alt="">
            <div class="center">
                <br>
                <p>
                    <?php echo e($event->description); ?>

                </p>
            
            <hr>
            <?php if($event->tickets > 0): ?>
                <p>tickets available: <?php echo e($event->tickets - DB::table('event_register')->where('event_id',$event->id)->value('tickets')); ?></p>
                <hr>
            <?php endif; ?>
            <p>Date: <?php echo e($event->event_date); ?></p>
            <hr>
            <small>Created on <?php echo e($event->created_at); ?> by <?php echo e($event->organizer); ?></small>
        </div>
        <hr>
    
    
    <?php if(!Auth::guest()): ?>
        
        
        <?php if(DB::table('event_register')->where('user_id', Auth::user()->id)->where('event_id',$event->id)->doesntExist()): ?>
            <a href="<?php echo e($event->id); ?>/register" class="btn btn-success">Register Event</a>
            <?php else: ?>
            <span>You have registered <b class="secondary-color"><?php echo e(DB::table('event_register')->where('user_id', Auth::user()->id)->where('event_id',$event->id)->value('tickets')); ?></b> ticket(s)</span>

            
            
            <?php if(DB::table('events')->where($event->id,50)): ?>
            <?php echo Form::open(['action'=>['EventsController@cancelRegisteration', $event->id], 'method'=>'POST', 'class'=>'pull-right']); ?>

            
            <?php echo e(Form::hidden('_method','DELETE')); ?>

            <?php echo e(Form::submit('Cancel Registeration',['class'=>'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

    
    <?php if(!Auth::guest()): ?>
        
        <?php if(Auth::user()->id == $event->organizer_id || Auth::user()->privilege == 'admin'): ?>
        <hr>
            
            <a href="<?php echo e($event->id); ?>/edit" class="btn btn-warning">Edit Event</a>

            
            <?php echo Form::open(['action'=>['EventsController@destroy', $event->id], 'method'=>'POST', 'class'=>'pull-right']); ?>

                
                <?php echo e(Form::hidden('_method','DELETE')); ?>

                <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

            <a href="<?php echo e($event->id); ?>/viewRegister" class="btn btn-primary">View Registeration</a>
        <?php endif; ?>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/events/show.blade.php ENDPATH**/ ?>