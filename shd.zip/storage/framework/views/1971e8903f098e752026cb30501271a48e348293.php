<?php $__env->startSection('content'); ?>
<style>
        body{
            margin-top: 56px !important;
        }
        </style>
<div class="container">
<div class="jumbotron">
    <h2>List of Users</h2>
    <table class="table table-striped">
            <tr>
                <th>Name</th>
                <th>Privilege</th>
                <th></th>
            </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->privilege); ?></td>
                    
                    <td>
                            <?php echo Form::open(['action'=>['UsersController@destroy',$user->id], 'method'=>'POST','class'=>"float-right"]); ?>


                            <?php echo e(Form::hidden('_method',"DELETE")); ?>

                            <?php echo e(Form::submit("Delete User",['class'=>'btn btn-danger'])); ?>

                    
                            <?php echo Form::close(); ?>


                    </td>
                </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a class="btn btn-info" href="export-users-pdf">Export List as PDF</a>
    <hr>
    <a href="home" class="btn btn-secondary">&larr; Back to Dashboard</a>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/admin/index.blade.php ENDPATH**/ ?>