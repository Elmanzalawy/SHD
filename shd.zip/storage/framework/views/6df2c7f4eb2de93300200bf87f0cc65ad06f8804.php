<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">

    <a class="navbar-brand" href="<?php echo e(url('/index')); ?>"><b>SHD</b></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav text-left">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/index')); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      
    <!--EXAM ARCHIVE-->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Exam Archive
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo e(url('/exams/level1.php')); ?>">Level 1</a>
          <a class="dropdown-item" href="<?php echo e(url('/exams/level2.php')); ?>">Level 2</a>
          <a class="dropdown-item" href="<?php echo e(url('/exams/level3.php')); ?>">Level 3</a>
          <a class="dropdown-item" href="<?php echo e(url('/exams/level4.php')); ?>">Level 4</a>
          <a class="dropdown-item" href="<?php echo e(url('/exams/level5.php')); ?>">Level 5</a>
        </div>
      </li>
    <!--ACADEMICS-->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Lectures &amp; Sections</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo e(url('/lectures/level1.php')); ?>">Level 1</a>
          <a class="dropdown-item" href="<?php echo e(url('/lectures/level2.php')); ?>">Level 2</a>
          <a class="dropdown-item" href="<?php echo e(url('/lectures/level3.php')); ?>">Level 3</a>
          <a class="dropdown-item" href="<?php echo e(url('/lectures/level4.php')); ?>">Level 4</a>
          <a class="dropdown-item" href="<?php echo e(url('/lectures/level5.php')); ?>">Level 5</a>
        </div>
      </li>
    <!--ABOUT US-->
        <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/about')); ?>">About Us</a>
      </li>
      
      <?php if(!Auth::guest()): ?>
      <li class="nav-item">
      <a href="#" class="nav-link contact-us" data-toggle="modal" data-target="#contact-us-modal">Contact Us</a>
      </li>
      <?php endif; ?>
    
    </ul>
    <!-- Right Side Of Navbar -->
    <ul class="navbar-nav ml-auto">
      <!-- Authentication Links -->
      <?php if(auth()->guard()->guest()): ?>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
          </li>
          <?php if(Route::has('register')): ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
          <?php endif; ?>
      <?php else: ?>
          <li class="nav-item dropdown">
              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
              </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                     onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?>

                  </a>
                  <a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form>
              </div>
          </li>
      <?php endif; ?>
  </ul>
    </div>
    </nav><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/includes/navbar.blade.php ENDPATH**/ ?>