<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LectureArchive extends Model
{
    public $table = "lecture_archive";
}
