<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class ExamArchive extends Model
{
    public $table = "exam_archive";
}
