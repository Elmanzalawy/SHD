<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>
<div class="container">
    <div class="jumbotron bg-none">
        <h1 class="center">Register event "<?php echo e($event->title); ?>"</h1>
            <?php echo e(Form::open(['action' => ['EventsController@uploadRegister', $event->id], 'method'=>'POST'])); ?>


            <div class="form-group">
                <?php echo e(Form::label('title','Number of tickets')); ?>

                <?php echo e(Form::number('tickets','1',['class'=>'form-control'])); ?>

            </div>
    
            <div class="form-group">
                <?php echo e(Form::label('notes','notes (optional)')); ?>

                <?php echo e(Form::textarea('notes','',['class'=>'form-control','placeholder'=>'leave notes here...'])); ?>

            </div>
    
            
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Register',['class'=>'btn btn-primary'])); ?>

        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views//events/register.blade.php ENDPATH**/ ?>