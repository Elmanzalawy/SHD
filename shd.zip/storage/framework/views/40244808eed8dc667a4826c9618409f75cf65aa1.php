<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
        <?php if(!Auth::guest()): ?>
        <h3>Welcome, <?php echo e(Auth::user()->name); ?></h3>

            
        <?php if(Auth::user()->privilege==="admin"): ?>
            <hr>
            <h3>Administrator Control</h3>
            <a href="#" data-toggle="modal" data-target="#create-user-modal" class="btn btn-primary">Create New User</a>
            <a href="view-users" class="btn btn-secondary">View Users</a>
            <?php if(Auth::user()->privilege === 'admin'): ?>
            

            <!--MODAL-->
       <div class="modal fade" id="create-user-modal" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Create New User</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                        <?php echo e(Form::open(['action' => 'UsersController@store', 'method'=>'POST', 'enctype'=>'multipart/form-data'])); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('name','Username')); ?>

                            <?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'username'])); ?>

                        </div>
                
                        <div class="form-group">
                                <?php echo e(Form::label('email','Email')); ?>

                                <?php echo e(Form::email('email','',['class'=>'form-control','placeholder'=>'example@gmail.com'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('password','Password')); ?>

                            <input name="password" type="password" class="form-control" placeholder="password">
                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('privilege','Privilege')); ?>

                            <select name="privilege" class="form-control" id="privilege">
                                <option value="admin">Adminstrator</option>
                                <option value="moderator">Moderator</option>
                                <option value="else">Else</option>
                            </select>
                        </div>
                
                        <?php echo e(Form::submit('Create User',['class'=>'btn btn-success'])); ?>

                    <?php echo e(Form::close()); ?>

                   </div>
                </div>
              </div>
           </div>
       </div>
            <?php endif; ?>
        <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>