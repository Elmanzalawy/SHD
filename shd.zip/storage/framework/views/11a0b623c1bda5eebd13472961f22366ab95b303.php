<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>

<div class="container">
    <div class="jumbotron">
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->privilege == "admin"): ?>
            <a class="btn btn-lg btn-primary" href="<?php echo e(url('/events/create')); ?>">Create New Event</a>
        <?php endif; ?>
    <?php endif; ?>
    <h1 style="margin-top:2rem !important;" class="center">UPCOMING EVENTS</h1>
    <?php if(count($events) > 0): ?>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card p-3 my-2">
                <div class="row">
                    <div class="col-md-4 col-sm-4">
                        <img style="width:100%;" src="../storage/app/public/event_images/<?php echo e($event->cover_image); ?>" alt="">
                    </div>
                    <div class="col-md-8 col-sm-8 text-center">
                        <h3><a href="events/<?php echo e($event->id); ?>"><?php echo e($event->title); ?></a></h3>
                        <p style="background:lavender;padding:5px;border-radius:10px;"><?php echo e($event->description); ?></p>
                        <p>Event date: <?php echo e($event->event_date); ?></p>
                        <?php if($event->tickets > 0): ?>
                            <p>tickets available: <?php echo e($event->tickets - DB::table('event_register')->where('event_id',$event->id)->value('tickets')); ?></p>
                        <?php endif; ?>
                        <hr>
                        <small>Created on <?php echo e($event->created_at); ?> by <?php echo e($event->organizer); ?></small>                </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($events->links()); ?>

    <?php else: ?>
        <p>No upcoming events.</p>
    <?php endif; ?>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/events/index.blade.php ENDPATH**/ ?>