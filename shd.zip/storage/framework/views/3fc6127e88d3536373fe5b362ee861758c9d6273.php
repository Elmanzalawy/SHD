<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>
<div class="container">
    <div class="jumbotron bg-none">
            <?php echo e(Form::open(['action' => 'EventsController@store', 'method'=>'POST', 'enctype'=>'multipart/form-data'])); ?>

            <div class="form-group">
                <?php echo e(Form::label('title','Event Name')); ?>

                <?php echo e(Form::text('title','',['class'=>'form-control','placeholder'=>'Title'])); ?>

            </div>
    
            <div class="form-group">
                    <?php echo e(Form::label('title','Event Date')); ?>

                    <?php echo e(Form::date('event_date','',['class'=>'form-control','placeholder'=>'event_date'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('title','tickets available (leave empty if no max number is available)')); ?>

                <?php echo e(Form::number('tickets','',['class'=>'form-control','placeholder'=>''])); ?>

            </div>
    
            <div class="form-group">
                <?php echo e(Form::label('description','Description')); ?>

                <?php echo e(Form::textarea('description','',['class'=>'form-control','placeholder'=>'Description Text'])); ?>

            </div>
    
            <div class="form-group">
                    <?php echo e(Form::label('Add image: ','Add image:')); ?>

                    <?php echo e(Form::file('cover_image')); ?>

            </div>
    
            <?php echo e(Form::submit('Submit',['class'=>'btn btn-success'])); ?>

        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/events/create.blade.php ENDPATH**/ ?>