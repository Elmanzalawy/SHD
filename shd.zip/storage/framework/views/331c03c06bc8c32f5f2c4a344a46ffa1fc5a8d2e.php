<?php $__env->startSection('content'); ?>
<style>
body{
    margin-top: 56px !important;
}
</style>
<div class="container">
    <div class="jumbotron bg-none">
        <h1 class="center">Register Event <?php echo e($event->title); ?></h1>
            <?php echo e(Form::open(['action' => 'EventsController@uploadRegister', 'method'=>'POST'])); ?>


            <div class="form-group">
                <?php echo e(Form::label('title','Number of tickets (leave empty if no max number is available)')); ?>

                <?php echo e(Form::number('tickets','',['class'=>'form-control','placeholder'=>''])); ?>

            </div>
    
            <div class="form-group">
                <?php echo e(Form::label('notes','notes')); ?>

                <?php echo e(Form::textarea('notes','',['class'=>'form-control','placeholder'=>'leave notes here...'])); ?>

            </div>
    

            <?php echo e(Form::submit('Register',['class'=>'btn btn-success'])); ?>

        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/events/register.blade.php ENDPATH**/ ?>