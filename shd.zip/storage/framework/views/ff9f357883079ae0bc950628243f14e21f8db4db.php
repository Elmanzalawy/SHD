<?php $__env->startSection('content'); ?>

<div class="jumbotron">
  <div class="container">
      <h1 class="center">Level <?php echo e($level); ?> Lecture Archive</h1>
      <div>
        <?php if(!Auth::guest()): ?>
        <a class="btn btn-primary btn-sm contact-designer mb-1"  href="#" data-toggle="modal" data-target="#upload-lecture-modal"><span class="fa fa-upload" style="padding-right:3px;font-size: 17px;"></span> Upload Lecture / Section</a>
        <?php endif; ?>
      </div>
      <div>
          <button class="btn btn-primary btn-sm mb-1 trigger-all">Show all</button>
          <button class="btn btn-secondary btn-sm mb-1 trigger-civil">Show Civil Only</button>
          <button class="btn btn-secondary btn-sm mb-1 trigger-communication">Show Communication Only</button>
          <button class="btn btn-secondary btn-sm mb-1 trigger-chemical">Show Chemical Only</button>
        </div>
      <?php if(!Auth::guest()): ?>
      <!--MODAL-->
       <div class="modal fade" id="upload-lecture-modal" tabindex="1" role="dialog" aria-labelledby="lecturepleModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered" role="document">
           <div class="modal-content">
             <div class="modal-header">
               <h5 class="modal-title" id="LectureModalLabel">Upload lecture</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <div class="modal-body">
                <?php echo e(Form::open(['action' => ['LecturesController@uploadLecture', 3], 'method'=>'POST', 'enctype'=>'multipart/form-data'])); ?>

                <div class="form-group">
                    
                    <?php echo e(Form::label('title','Select Department')); ?>

                    <select class="form-control" id="select-department" name="department">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department); ?>"><?php echo e($department); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                    
                    <?php echo e(Form::label('title','Select Subject')); ?>

                    <select class="form-control" id="select-subject" name="subject">
                        <option value=""></option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department => $subs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="<?php echo e($department); ?>" value="<?php echo e($sub); ?>"><?php echo e($sub); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
        
                <div class="form-group">
                    <label for="lecture-type" class="col-form-label">Choose Type:</label>
                    <select class="form-control" id="select-type" name="type">
                      <option value=""></option>
                     <option value="Lecture">Lecture</option>
                     <option value="Section">Section</option>
                     <option value="Other">Other</option>
                   </select>
                </div>
                        
                <div class="form-group">
                    <label for="lecture-image" class="col-form-label">Images or PDF:</label>
                    <input type="file" class="form-control" id="lecture-file" name="lectures[]" value="Upload images, PDF, or PowerPoint" multiple>
                </div>
                
                <?php echo e(Form::hidden('_method','GET')); ?>

                <?php echo e(Form::submit('Upload',['class'=>'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>

               
             </div>
           </div>
        </div>
    </div>
    <?php endif; ?>
    <!--ACCORDION-->
  <div class="accordion" id="accordion-example">
      <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department => $subs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo $__env->make('includes.lecture_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/lectures/level3.blade.php ENDPATH**/ ?>