<!--CREATE EVENT-->
<div class="modal fade" id="modal-name" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" enctype="multipart/form-data" action="">
            <!--set level-->
            <div class="form-group">
            </div>
            <!-- set department -->
            <div class="form-group">
              <label for="lecture-department" class="col-form-label">Username</label>
              <input type="text" class="form-control" name="username">
           </div>
            <!-- set department -->
            <div class="form-group">
              <label for="lecture-department" class="col-form-label">Password</label>
              <input type="text" class="form-control" name="password">
           </div>
            <!-- set subject-->
            <div class="form-group">
              <label for="lecture-subject" class="col-form-label">Choose Subject:</label>
              <select class="form-control" id="select-subject" name="select-subject">
                <option value=""></option>
                <option class="general" value="Engineering Economy">Engineering Economy</option>
                <option class="general" value="Numerical Methods">Numerical Methods</option>
                <option class="general" value="Statistics Analysis">Statistics Analysis</option>
             </select>
            </div>
            <!-- set images or pdf -->
            <div class="form-group">
              <label for="lecture-image" class="col-form-label">lecture image:</label>
              <input type="file" class="form-control" id="lecture-file" name="lectures[]" value="Upload Images or PDF" multiple>
            </div>
            <!-- submit form -->
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
              <input type="submit" name="upload-lecture" value="Upload lecture" class="btn btn-primary">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
 <?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/templates/event_form.blade.php ENDPATH**/ ?>