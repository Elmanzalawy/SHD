<h2>
    invoice goes here
    <img src="<?php echo e(url('DeadForest.jpg')); ?>" alt="image">
    <img src="DeadForest.jpg" alt="image">
    <img src="DeadForest.jpg" alt="image">
</h2><?php /**PATH D:\Programs\XAMPP\htdocs\shd\shd\resources\views/invoice.blade.php ENDPATH**/ ?>