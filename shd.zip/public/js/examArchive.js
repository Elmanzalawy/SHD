$(document).ready(function(){
    // var selectLevel = $("select[name='select-level']");
    var selectDept = $("select[name='department']");
    var selectSub = $("select[name='subject']");

    // $("option[value='general']").hide();
    $("select[name='subject'] option").show();
    function checkDept(){
      if(selectDept.val()=="general"){
        $("option[class='general']").show();
        $("option[class='civil']").show();
        $("option[class='communication']").show();
        $("option[class='chemical']").show();
  
      }
      else if(selectDept.val()=="civil"){
        $("option[class='general']").show();
        $("option[class='civil']").show();
        $("option[class='communication']").hide();
        $("option[class='chemical']").hide();

      }
      else if(selectDept.val()=="communication"){
        $("option[class='general']").show();
        $("option[class='civil']").hide();
        $("option[class='communication']").show();
        $("option[class='chemical']").hide();

      }
      else if(selectDept.val()=="chemical"){
        $("option[class='general']").show();
        $("option[class='civil']").hide();
        $("option[class='communication']").hide();
        $("option[class='chemical']").show();
      }

      //solve duplicate subjects
      if($(".trigger-all").hasClass('btn-primary')){
        for (let index = 0; index < array.length; index++) {
          const element = array[index];
          
        }
      }
    }
    selectDept.change(function(){
        checkDept();
        selectSub.val()=='';
    });


    //Departments buttons
    $(".trigger-civil").click(function(){
        $(".card-communication, .card-chemical").hide();
        $(".card-general, .card-civil").show();
        $(this).addClass("btn-primary");
        $(this).removeClass("btn-secondary");
        $(this).siblings().removeClass("btn-primary");
        $(this).siblings().addClass("btn-secondary");
    });
    $(".trigger-communication").click(function(){
        $(".card-civil, .card-chemical").hide();
        $(".card-general, .card-communication").show();
        $(this).addClass("btn-primary");
        $(this).removeClass("btn-secondary");
        $(this).siblings().removeClass("btn-primary");
        $(this).siblings().addClass("btn-secondary");
    });
    $(".trigger-chemical").click(function(){
        $(".card-civil, .card-communication").hide();
        $(".card-general, .card-chemical").show();
        $(this).addClass("btn-primary");
        $(this).removeClass("btn-secondary");
        $(this).siblings().removeClass("btn-primary");
        $(this).siblings().addClass("btn-secondary");
    });
    $(".trigger-all").click(function(){
        $(".card-civil, .card-communication, .card-chemical").show();
        $(this).addClass("btn-primary");
        $(this).removeClass("btn-secondary");
        $(this).siblings().removeClass("btn-primary");
        $(this).siblings().addClass("btn-secondary");
        checkDuplicates();
    });

    //check duplicate subjects in case of 'show all' enabled
    function checkDuplicates(){
      const subjects = document.getElementsByClassName('select-subject');
      var subjectNames = new Array(); //get name of each subject
      var duplicateSubjects = new Array(); //get name of duplicate subjects
      console.log(subjects);
      for(let i=0;i<subjects.length;i++){
        console.log(subjects[i].innerText);
        subjectNames.push(subjects[i].innerText);
      }
      console.log(subjectNames);
      for(let j=0;j<subjectNames.length;j++){
        let currentName = subjectNames[j]; //current subject name to perform the duplicate test on
        let duplicateCount = 0;
        for(let k=0;k<subjectNames.length;k++){
          if(currentName == subjectNames[k]){
            duplicateCount++;
            if(duplicateCount>=2)
            duplicateSubjects.push(subjectNames.indexOf(subjectNames[k])); //push the index of the duplicate subject
          }else{
            continue;
          }
        }
      }
      for(let i=0;i<duplicateSubjects.length;i++){
        subjects[duplicateSubjects[i]].style.display='none'; //hide duplicate elements;
        console.log('duplicate: '+subjects[duplicateSubjects[i]].innerText.trim()); //log all duplicate subjects

      }
      console.log('duplicate indexes: '+ duplicateSubjects);
    }
});